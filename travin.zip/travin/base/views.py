from django.shortcuts import render
from django.contrib.auth.models import User

# Create your views here.
def home(request):
    return render(request,"homepage.html")

def register(request):
     
    return render(request,"register.html")

def userlogin(request):
    return render(request,"login.html")

def destinations(request):
    return render(request,"destinations.html")

def packages(request):
    return render(request,"packages.html")

def packagedetails(request):
    return render(request,"packagedetails.html")

def booking(request):
    return render(request,"booking.html")

def payment(request):
    return render(request,"payment.html")